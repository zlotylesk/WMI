import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;
public class Testy
{
	String LOGIN = "";
	String PASS = "";
	
	WebDriver driver = new HtmlUnitDriver();
	
	public void zaloguj()
	{
		WebElement element = driver.findElement(By.name("user"));
		element.sendKeys(LOGIN);
		element = driver.findElement(By.name("pass"));
		element.sendKeys(PASS);
		element.submit();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		if (bodyText.contains("Zalogowany jako: " + LOGIN))
		{
			System.out.println("Poprawnie zalogowano");
		}
		else
		{
			System.out.println("Nie uda�o si� zalogowa�!");
		}
	}
	
	public void dodajOgloszenie()
	{
		driver.findElement(By.partialLinkText("Dodaj og�oszenie")).click();
		WebElement element = driver.findElement(By.name("tytul"));
		element.sendKeys("Przyk�adowe og�oszenie");
		element = driver.findElement(By.name("tresc"));
		element.sendKeys("Przyk�adowa tre��");
		WebElement dropDownListBox = driver.findElement(By.name("category"));
		Select clickThis = new Select(dropDownListBox);
		clickThis.selectByVisibleText("Oferty");
		dropDownListBox = driver.findElement(By.name("group"));
		clickThis = new Select(dropDownListBox);
		clickThis.selectByVisibleText("ALL");
		element.submit();
		driver.findElement(By.partialLinkText("Og�oszenia")).click();
		List<WebElement> lista = driver.findElements(By.name("submit"));
		lista.get(3).click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		boolean t1 = bodyText.contains("Przyk�adowe og�oszenie");
		boolean t2 = bodyText.contains("Og�oszenie dodane przez: " + LOGIN);
		boolean t3 = bodyText.contains("Przyk�adowa tre��");
		if (t1 && t2 && t3)
		{
			System.out.println("Poprawnie dodano og�oszenie");
		}
		else
		{
			System.out.println("Nie uda�o si� doda� og�oszenia!");
		}
	}
	
	public void edytujOg�oszenie()
	{
		driver.findElement(By.partialLinkText("Edytuj og�oszenia")).click();
		WebElement element = driver.findElement(By.name("ok"));
		element.click();
		element = driver.findElement(By.name("tytul"));
		element.clear();
		element.sendKeys("Edytowane przyk�adowe og�oszenie");
		element = driver.findElement(By.name("tresc"));
		element.clear();
		element.sendKeys("Edytowana przyk�adowa tre��");
		WebElement dropDownListBox = driver.findElement(By.name("category"));
		Select clickThis = new Select(dropDownListBox);
		clickThis.selectByVisibleText("Oferty");
		element.submit();
		driver.findElement(By.partialLinkText("Og�oszenia")).click();
		List<WebElement> lista = driver.findElements(By.name("submit"));
		lista.get(3).click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		boolean t1 = bodyText.contains("Edytowane przyk�adowe og�oszenie");
		boolean t2 = bodyText.contains("Og�oszenie dodane przez: " + LOGIN);
		boolean t3 = bodyText.contains("Edytowana przyk�adowa tre��");
		if (t1 && t2 && t3)
		{
			System.out.println("Poprawnie edytowano og�oszenie");
		}
		else
		{
			System.out.println("Nie uda�o si� edytowa� og�oszenia!");
		}
	}
	
	public void usuniecieOgloszenia()
	{
		driver.findElement(By.partialLinkText("Edytuj og�oszenia")).click();
		List<WebElement> lista = driver.findElements(By.name("ok"));
		lista.get(1).click();
		WebElement element = driver.findElement(By.name("submit"));
		element.click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		if (bodyText.contains("Usuni�to og�oszenie!"))
		{
			System.out.println("Poprawnie usuni�to og�oszenie");
		}
		else
		{
			System.out.println("Nie uda�o si� usun�� og�oszenia!");
		}
	}
	
	public void dolaczDoGrupy()
	{
		driver.get("http://bialaarmia.wmi.amu.edu.pl/group.php?all=1");
		WebElement element = driver.findElement(By.name("submit"));
		element.click();
		element = driver.findElement(By.name("submit"));
		element.click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		if (bodyText.contains("Do��czy�e� do grupy"))
		{
			System.out.println("Poprawnie do��czono do grupy");
		}
		else
		{
			System.out.println("Nie uda�o si� do��czy� do grupy!");
		}
	}
	
	public void opuscGrupe()
	{
		driver.get("http://bialaarmia.wmi.amu.edu.pl/group.php?my=1");
		WebElement element = driver.findElement(By.name("submit"));
		element.click();
		element = driver.findElement(By.name("submit"));
		element.click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		if (bodyText.contains("Opu�ci�e� grup�."))
		{
			System.out.println("Poprawnie opuszczono grup�");
		}
		else
		{
			System.out.println("Nie uda�o si� opu�ci� grupy!");
		}
	}
	
	public void wyloguj()
	{
		WebElement element = driver.findElement(By.name("logout"));
		element.click();
		String bodyText = driver.findElement(By.tagName("body")).getText();
		if (bodyText.contains("Zosta�e� wylogowany z serwisu."))
		{
			System.out.println("Poprawnie wylogowano");
		}
		else
		{
			System.out.println("Nie uda�o si� wylogowa�!");
		}
	}
	
	public void start()
	{
		driver.get("http://bialaarmia.wmi.amu.edu.pl/index.php");
		zaloguj();
		dodajOgloszenie();
		edytujOg�oszenie();
		usuniecieOgloszenia();
		dolaczDoGrupy();
		opuscGrupe();
		wyloguj();
	}
	
	public static void main(String[] args)
	{
		new Testy().start();
	}
}